from Scripts.game_map import GameMap

GAME_SURFACE = None
GAME_MAP = GameMap
LOAD_FUNC = None
loading = False
